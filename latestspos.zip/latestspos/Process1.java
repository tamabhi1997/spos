import java.util.Comparator;
public class Process1{
     int BT,AT,CT,TAT,WT,PR,remBT;
     String name;
     boolean flag;
     public Process1(String name,int bt,int at)
     {
         this.name=name;
         BT=bt;
         this.AT=at;
         remBT=BT;
         TAT=WT=CT=0;
         PR=0;
     }
     
     public Process1(String name,int bt,int at,int prior)
     {
         this.name=name;
         this.AT=at;
         BT=bt;
         remBT=BT;
         TAT=WT=CT=0;
         PR=prior;
         flag=false;
     }
     
     public void display()
     {
        System.out.println(""+name+"\t"+BT+"\t"+AT+"\t"+CT+"\t"+TAT+"\t"+WT+"\t"+PR);
     }
     }
     class SortByArrival implements Comparator<Process1>
     {
        @Override
        public int compare(Process1 p1,Process1 p2)
        {
            return p1.AT-p2.AT;
        }
     }
     class SortByPriority implements Comparator<Process1>
     {
        @Override
        public int compare(Process1 o1,Process1 o2)
        {
            return o1.PR-o2.PR;
        }
        
     }

