import java.util.*;

public class prac2sjf
{
   public void execute()
   {
      boolean flag=false;
      Scanner sc=new Scanner(System.in);
      int at,bt,num,time=0,sum=0,min=200,count=0,shortest=0;
      float avgTaT=0,avgWt=0;
      System.out.println("Enter the number of processes");
      num=sc.nextInt();
      Pracpro process[]=new Pracpro[num];
      for(int i=0;i<num;i++)
      {
         System.out.println("P("+(i+1)+"):Enter the arrival time and burst time");
         at=sc.nextInt();
         bt=sc.nextInt();
         process[i]=new Pracpro("P("+(i+1)+")",bt,at);
      }
    while(count<num)
    {
      
      for(int i=0;i<num;i++)
      {
         if(process[i].AT<=time && (process[i].remBT<min && process[i].remBT>0))
         {
            shortest=i;
            min=process[i].remBT;
            flag=true;
         }
      }
      if(flag==false)
      {
         time++;
         continue;
      }
      process[shortest].remBT--;
      min=process[shortest].remBT;
      if(min==0)
      {
         min=200;
         process[shortest].remBT=0;
         sum=time+1;
         count++;
         process[shortest].CT=sum;
         process[shortest].TAT=process[shortest].CT-process[shortest].AT;
         process[shortest].WT=process[shortest].TAT-process[shortest].BT;
         avgTaT=avgTaT+process[shortest].TAT;
         avgWt=avgWt+process[shortest].WT;
         process[shortest].display();
      }
      time++;
    }
      
      
   }
   public static void main(String[] args)
   {
      prac2sjf pf=new prac2sjf();
      pf.execute();
   }
}
