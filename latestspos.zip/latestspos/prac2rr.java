import java.util.*;

public class prac2rr
{
   public static void main(String[] args)
   {
       int num,quant,count=0;
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the number of processes");
       num=sc.nextInt();
       System.out.println("Enter the quantum time");
       quant=sc.nextInt();
       int at[]=new int[num];
       int bt[]=new int[num];
       int ct[]=new int[num];
       int tat[]=new int[num];
       int wt[]=new int[num];
       int f[]=new int[num];  // finish
       int k[]=new int[num];
       int arrive[]=new int[num];
       int queue[]=new int[200];
       int front=0,back=0,st=0,c;
       float avgtat=0,avgwt=0;
       for(int i=0;i<num;i++)
       {
          System.out.println("(P"+(i+1)+"): Enter the arrival time and burst time");
          at[i]=sc.nextInt();
          bt[i]=sc.nextInt();
          k[i]=bt[i];
          f[i]=0;
          arrive[i]=0;
       }
       for(int i=0;i<num;i++)
       {
          if(at[i]<=st && (f[i]==0 && arrive[i]==0))
          {
              arrive[i]=1;
              queue[front]=i;
              front++;
          }
       }
       
       
       while(count<num)
       {
          c=queue[back];
          back++;
          
          if(k[c]<=quant)
          {
             st=st+k[c];
             k[c]=0;
             f[c]=1;
             count++;
             ct[c]=st;
          }
          else
          {
            st=st+quant;
            k[c]=k[c]-quant; 
          }
          
          for(int i=0;i<num;i++)
          {
              if(at[i]<=st && (f[i]==0 && arrive[i]==0))
              {
                 arrive[i]=1;
                 queue[front]=i;
                 front++;
              }
       
          }
          if(f[c]!=1)
          {
             queue[front]=c;
             front++;
          }
        }
        for(int i=0;i<num;i++)
        {
          tat[i]=ct[i]-at[i];
          wt[i]=tat[i]-bt[i];
          avgtat=avgtat+tat[i];
          avgwt=avgwt+wt[i];
        }
      
      System.out.println("The table is \n ");
      for(int i=0;i<num;i++)
      {
         System.out.println(at[i]+"\t"+bt[i]+"\t"+ct[i]+"\t"+tat[i]+"\t"+wt[i]);
      }
      avgtat=(float)avgtat/num;
      avgwt=(float)avgwt/num;
      System.out.println("Average tat is "+avgtat);
      System.out.println("Average wt is"+avgwt);
       
       
   }
}
