import java.util.*;

public class prac2prior
{
   public void execute()
   {
      Scanner sc=new Scanner(System.in);
      int at,bt,num,pr;
      float avgTaT=0,avgWt=0;
      System.out.println("Enter the number of processes");
      num=sc.nextInt();
      Pracpro process[]=new Pracpro[num];
      for(int i=0;i<num;i++)
      {
         System.out.println("P("+(i+1)+"):Enter the burst time and priority");
         at=0;
         bt=sc.nextInt();
         pr=sc.nextInt();
         process[i]=new Pracpro("P("+(i+1)+")",bt,at,pr);
      }
      Arrays.sort(process,new SortByPriority());
      int sum=process[0].AT;
      
      for(int i=0;i<num;i++)
      {
         sum=process[i].CT=sum+process[i].BT;
         process[i].TAT=process[i].CT-process[i].AT;
         process[i].WT=process[i].TAT-process[i].BT;
         avgTaT=avgTaT+process[i].TAT;
         avgWt=avgWt+process[i].WT;
         process[i].display();
      }
      avgTaT=(float)avgTaT/num;
      avgWt=(float)avgWt/num;
      System.out.println("The average turnaround time "+avgTaT);
      System.out.println("The average waiting time "+avgWt);
      
   }
   public static void main(String[] args)
   {
      prac2prior pf=new prac2prior();
      pf.execute();
   }
}
