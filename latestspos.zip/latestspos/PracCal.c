#include <jni.h>
#include "PracCal.h"
#include <stdio.h>
#include <math.h>

JNIEXPORT jint JNICALL add(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jint res;
   res=n1+n2;
   return res;
}

JNIEXPORT jint JNICALL sub(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jint res;
   res=n1-n2;
   return res;
}

JNIEXPORT jint JNICALL mul(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jint res;
   res=n1*n2;
   return res;
}

JNIEXPORT jfloat JNICALL div(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jfloat res;
   res=n1/n2;
   return res;
}
