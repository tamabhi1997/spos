import java.util.*;
import java.io.*;

public class pracbanker
{
   public static void main(String[] args)
   {
      int n,m,count=0;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the number of resources");
      m=sc.nextInt();
      System.out.println("Enter the number of processes");
      n=sc.nextInt();
      int allocation[][]=new int[n][m];
      int max[][]=new int[n][m];
      int need[][]=new int[n][m];
      int available[]=new int[m];
      boolean finish[]=new boolean[n];
      int safeseq[]=new int[n];
      boolean found=false;
      
      System.out.println("Enter the allocation matrix");
      for(int i=0;i<n;i++)
      {
         for(int j=0;j<m;j++)
         {
            allocation[i][j]=sc.nextInt();
         }
         
      }
      
      System.out.println("Enter the Max matrix");
      for(int i=0;i<n;i++)
      {
         for(int j=0;j<m;j++)
         {
            max[i][j]=sc.nextInt();
         }
         
      }
      
      System.out.println("the need matrix");
      for(int i=0;i<n;i++)
      {
         for(int j=0;j<m;j++)
         {
            need[i][j]=max[i][j]-allocation[i][j];
         }
         
      }
      
      System.out.println(" The need matrix is ");
      for(int i=0;i<n;i++)
      {
         for(int j=0;j<m;j++)
         {
            System.out.print("\t"+need[i][j]);
         }
         System.out.println();
      }
      
      System.out.println("Enter the available matrix");
      for(int i=0;i<m;i++)
      {
          available[i]=sc.nextInt();
      }
      
      for(int i=0;i<n;i++)
      {
          finish[i]=false;
      }
      
      while(count<n)
      {
         found=false;
         for(int i=0;i<n;i++)
         {
            if(finish[i]==false)
            {
               int j=0;
               for(j=0;j<m;j++)
               {
                 if(need[i][j]>available[j])
                 {
                     break;
                 }
               }
               if(j==m)
               {
                  for(int k=0;k<m;k++)
                  {
                     available[k]=available[k]+allocation[i][k];
                  }
                  safeseq[count]=i+1;
                  found=true;
                  count++;
                  finish[i]=true;
                  
               }
            }
         }
         if(found==false)
         {
             System.out.println("Not a safe sequence ");
             break;
         }
      }
      System.out.println("The Safe sequence is ");
      for(int i=0;i<n;i++)
      {
         System.out.print(safeseq[i]+"-->");
      }
     /* System.out.println("Enter 1 if more requests can be made");
      int ch=sc.nextInt();
      if(ch==1)
      
      {
          
          System.out.println("Enter the need of the process ");
          int extraneed[]=new int[m];
          
          for(int i=0;i<m;i++)
          {
            extraneed[i]=sc.nextInt(); 
          }
          System.out.println("The need is ");
          for(int i=0;i<m;i++)
          {
            System.out.println("\t"+extraneed[i]); 
          }
          int j=0;
          for(int i=0;i<n;i++)
          {
            if(i==k)
            {
             for(j=0;j<m;j++)
             {
                if(available[j]<extraneed[j])
                {
                    break;
                }
                
             }
             if(j==m)
             {
     
                  found=true;
                  count++;
                  finish[i]=true;
                  System.out.println("The resource are allocated");
             }
             else
             {
                System.out.println("The resource cannot be allocated");
             }
            }
          }
           
          
      }*/
   }
}
